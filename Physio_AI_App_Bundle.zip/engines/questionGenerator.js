const questionsDB = require('../data/questions_db');

/**
 * AI Question Generator (Enhanced)
 * Selects questions from the Comprehensive Medical Question Database.
 */
class QuestionGenerator {
    constructor(doctorEngine) {
        this.doctor = doctorEngine;
    }

    async generateNextQuestion(history, currentDiagnosis) {
        // AI Logic:
        // 1. Establish Profile (Age, Gender - though Gender isn't in DB yet, assume Age is critical)
        // 2. Establish Pain Baseline (The most common reason for consult)
        // 3. Explore suspected areas based on Pain answers
        // 4. Round-robin check other pillars (Sleep, Stress, Nutrition) for holistic view.

        const askedIds = new Set(history.map(h => h.id));

        // --- PHASE 1: PREAMBLE ---
        if (!askedIds.has('age') && !askedIds.has('start_age')) {
            return { id: 'age', text: "What is your age?", type: 'slider', min: 10, max: 90 };
        }

        // --- PHASE 2: PAIN DOMAIN (Priority) ---
        // Iterate through critical pain questions first
        const painQuestions = questionsDB.pain;
        const nextPainQ = painQuestions.find(q => !askedIds.has(q.id));

        // If we haven't asked all pain questions, and we are in the early phase (< 4 questions), push pain
        if (nextPainQ && history.length < 5) {
            return nextPainQ;
        }

        // --- PHASE 3: DYNAMIC BRANCHING ---
        // If pain is "High" (>7), check Red Flags or specific triggers immediately
        const painLevel = history.find(h => h.id === 'p_int_rest' || h.id === 'pain_level');
        if (painLevel && parseInt(painLevel.answer) >= 7) {
            // Ensure we've asked about Red Flags (Numbness/Weakness/Night Pain)
            if (!askedIds.has('p_numb')) return questionsDB.pain.find(q => q.id === 'p_numb');
            if (!askedIds.has('p_night')) return questionsDB.pain.find(q => q.id === 'p_night');
        }

        // --- PHASE 3.5: SYSTEMIC REVIEW (New Request) ---
        // We inject a high-level "Review of Systems" check.
        // If we haven't asked about General Health, ask ONE key screening question.
        if (!askedIds.has('ros_fatigue') && !askedIds.has('ros_check_done')) {
            return questionsDB.constitutional[1]; // Ask about Fatigue/Weakness as a general screen
        }

        // If they answered YES to fatigue, we drill down into Constitutional/Inflammatory
        const fatigue = history.find(h => h.id === 'ros_fatigue');
        if (fatigue && fatigue.answer === 'Yes') {
            // Drill down logic: Priority -> Fever -> Uneasiness -> Inflammation
            const rosCats = ['constitutional', 'inflammatory', 'immune'];
            for (const cat of rosCats) {
                const nextQ = questionsDB[cat].find(q => !askedIds.has(q.id));
                if (nextQ) return nextQ;
            }
        }

        // If they reported Numbness in Pain section, drill into Neurology
        const numb = history.find(h => h.id === 'p_numb');
        if (numb && numb.answer === 'Yes') {
            const neuroQ = questionsDB.neurological.find(q => !askedIds.has(q.id));
            if (neuroQ) return neuroQ;
        }

        // Check Psych if Stress is high
        const stress = history.find(h => h.id === 'str_lvl');
        if (stress && parseInt(stress.answer) > 7) {
            const psychQ = questionsDB.psych_advanced.find(q => q.id === 'psy_anxiety' && !askedIds.has(q.id));
            if (psychQ) return psychQ;
        }

        // --- PHASE 4: HOLISTIC DEEP DIVE (Rigid 60-Question Protocol) ---
        // Cycle through categories, but instead of "Round Robin (One per turn)", 
        // we adhere to a "Block Structure" to ensure depth.
        // Or, to keep it dynamic but exhaustive, we iterate through categories and 
        // if a category is "Started but not Finished", we prioritize it.

        const categories = [
            'constitutional', 'inflammatory', 'immune', 'neurological',
            'pain',
            'cardio_history', // [NEW] Prioritize Safety history
            'mobility', 'posture', 'sleep', 'stress',
            'psych_behavioral', // [NEW] Anger/Focus
            'vision', // [NEW]
            'gastrointestinal', // [NEW]
            'cardio', 'strength', 'ergo',
            'habits', // [NEW]
            'nutrition', 'psych_advanced'
        ];

        for (const cat of categories) {
            const catQs = questionsDB[cat];
            if (!catQs) continue;

            const askedCount = catQs.filter(q => askedIds.has(q.id)).length;
            const totalCount = catQs.length;

            // Logic: If we have started this category (count > 0) AND not finished (count < total),
            // OR if we haven't touched it yet and it's its turn in the sequence.

            // To force "50-60 questions", we simply iterate and pick the first UNASKED question 
            // from the first category that isn't complete. 
            // This effectively serializes the survey: All Pain -> All Mobility -> All Posture...
            // which is very rigid and comprehensive.

            if (askedCount < totalCount) {
                // Find and return the next unasked question in this category
                const nextQ = catQs.find(q => !askedIds.has(q.id));
                if (nextQ) return nextQ;
            }
        }

        // If we run out of DB questions (unlikely for short survey) or hit the max count in engine.js
        return null;
    }
}

module.exports = QuestionGenerator;
