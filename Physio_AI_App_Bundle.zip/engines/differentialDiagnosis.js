/**
 * The 'Detective' Logic Module.
 * Uses Bayesian inference principles to rank diagnoses.
 */
class DifferentialDiagnosisEngine {
    constructor(kb) {
        this.kb = kb; // Expecting KnowledgeBase instance
    }

    analyze(symptoms) {
        const hypothesisRanking = {};

        // Iterate through every known disease in our DB
        for (const [pathology, traits] of Object.entries(this.kb.pathologySignatures)) {
            // Start with base prevalence probability (0.1 - 0.4)
            let probability = traits.probability_base || 0.1;

            // 1. Location Matching (Highest Weight)
            let matches = 0;
            const symptomLocations = symptoms.locations || [];

            symptomLocations.forEach(loc => {
                const locStr = loc.toLowerCase().replace(/_/g, " ");
                traits.regions.forEach(region => {
                    const regionStr = region.toLowerCase().replace(/_/g, " ");
                    // Flexible matching
                    if (regionStr.includes(locStr) || locStr.includes(regionStr)) {
                        matches += 1;
                    }
                });
            });

            if (matches > 0) {
                probability += (0.2 * matches);
            }

            // 2. Quality Matching (Descriptors)
            const symptomQuality = symptoms.quality || [];
            symptomQuality.forEach(q => {
                if (traits.quality.includes(q)) {
                    probability += 0.15;
                }
            });

            // 3. Aggravating Factors (Gold Standard for Physio)
            const symptomAggravators = symptoms.aggravators || [];
            symptomAggravators.forEach(agg => {
                if (traits.aggravators.includes(agg)) {
                    probability += 0.25;
                }
            });

            // Cap at 99% certainty
            hypothesisRanking[pathology] = Math.min(0.99, Math.round(probability * 1000) / 1000);
        }

        // Sort closest matches to the top
        const sortedHypotheses = Object.entries(hypothesisRanking)
            .sort(([, probA], [, probB]) => probB - probA);

        // Filter valid matches (>20% probability) and return top 3
        return sortedHypotheses
            .filter(([, prob]) => prob > 0.2)
            .slice(0, 3);
    }
}

module.exports = DifferentialDiagnosisEngine;
