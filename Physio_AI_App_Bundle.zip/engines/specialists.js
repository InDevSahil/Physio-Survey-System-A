/**
 * SPECIALIST ENGINES
 * Ported from Python "Physio Survey System"
 */

class AdvancedPainEngine {
    constructor(kb) { this.kb = kb; }
    analyze(data) {
        const score = data.pain_level || 0;
        const qualities = data.quality || [];

        let painType = "Nociceptive"; // Default: Tissue damage
        if (qualities.some(q => ['burning', 'shooting', 'electric'].includes(q))) {
            painType = "Neuropathic";
        }

        return {
            score: 100 - (score * 10),
            type: painType,
            descriptors: qualities
        };
    }
}

class AdvancedMobilityEngine {
    analyze(data) {
        // Functional Movement Screen (0-3 Scale per test)
        const tests = {
            'deep_squat': data.squat || 2,
            'hurdle_step': data.hurdle || 2,
            'inline_lunge': data.lunge || 2,
            'shoulder_mobility': data.shoulder || 2,
            'active_straight_leg_raise': data.aslr || 2,
            'trunk_stability_pushup': data.pushup || 2,
            'rotary_stability': data.rotary || 2
        };

        const totalScore = Object.values(tests).reduce((a, b) => a + b, 0);
        const maxPossible = 21;
        const scorePercent = (totalScore / maxPossible) * 100;

        const dysfunctions = [];
        const compensations = [];

        // Mobility Cluster
        const mobilityScore = tests['shoulder_mobility'] + tests['active_straight_leg_raise'];
        // Stability Cluster
        const stabilityScore = tests['trunk_stability_pushup'] + tests['rotary_stability'];

        let profileType = "Balanced";
        if (mobilityScore < 3 && stabilityScore > 4) {
            profileType = "Stiff / Stable (Needs Mobility Work)";
            dysfunctions.push("Global Mobility Restriction");
        } else if (mobilityScore > 4 && stabilityScore < 3) {
            profileType = "Flexible / Unstable (Needs Motor Control)";
            dysfunctions.push("Global Stability Deficit");
        }

        if (tests['trunk_stability_pushup'] <= 1) {
            dysfunctions.push("Anterior Core Inhibition");
            compensations.push("Lumbar Extension Strategy");
        }

        if (tests['active_straight_leg_raise'] <= 1) {
            if (tests['deep_squat'] <= 1) {
                dysfunctions.push("Functional Hamstring/Hip Tightness");
            } else {
                dysfunctions.push("Isolated Hamstring Restriction");
            }
        }

        let injuryRisk = "Low";
        if (totalScore <= 14) {
            injuryRisk = "High (2-4x Injury Risk)";
        } else if (Object.values(tests).some(s => s === 0)) {
            injuryRisk = "Pain-Dominant (Medical Referral Indicated)";
        }

        return {
            score: Math.round(scorePercent),
            fms_raw: totalScore,
            profile: profileType,
            dysfunctions: dysfunctions,
            compensations: compensations,
            injury_risk: injuryRisk
        };
    }
}

class AdvancedPostureEngine {
    analyze(data) {
        const head = data.head_position || 'neutral';
        const t_spine = data.thoracic_spine || 'neutral';
        const l_spine = data.lumbar_spine || 'neutral';
        const pelvis = data.pelvis || 'neutral';
        const shoulders = data.shoulders || 'neutral';

        const syndromes = [];
        const shortMuscles = [];
        const longMuscles = [];
        let scoreDeductions = 0;

        // 1. Upper Cross Syndrome
        let ucCount = 0;
        if (head === 'forward') ucCount++;
        if (t_spine === 'kyphotic' || shoulders === 'rounded') ucCount++;

        if (ucCount >= 1) {
            syndromes.push("Upper Cross Syndrome");
            shortMuscles.push("Upper Trapezius", "Levator Scapulae", "Pectoralis Major/Minor", "SCM");
            longMuscles.push("Deep Neck Flexors", "Lower Trapezius", "Serratus Anterior", "Rhomboids");
            scoreDeductions += 25;
        }

        // 2. Lower Cross Syndrome
        let lcCount = 0;
        if (pelvis === 'anterior_tilt') lcCount++;
        if (l_spine === 'hyperlordotic') lcCount++;

        if (lcCount >= 1) {
            syndromes.push("Lower Cross Syndrome Type A (Anterior)");
            shortMuscles.push("Iliopsoas", "Rectus Femoris", "Lumbar Erectors");
            longMuscles.push("Gluteus Maximus", "Gluteus Medius", "Transverse Abdominis");
            scoreDeductions += 25;
        } else if (pelvis === 'posterior_tilt' || l_spine === 'flat') {
            syndromes.push("Lower Cross Syndrome Type B (Posterior)");
            shortMuscles.push("Hamstrings", "Rectus Abdominis");
            longMuscles.push("Lumbar Multifidus", "Psoas Major");
            scoreDeductions += 25;
        }

        if (syndromes.includes("Upper Cross Syndrome") && syndromes.some(s => s.includes("Lower Cross"))) {
            syndromes.push("Stratification Syndrome (Poor Prognosis)");
            scoreDeductions += 10;
        }

        return {
            score: Math.max(0, 100 - scoreDeductions),
            syndromes: syndromes,
            facilitated_muscles: [...new Set(shortMuscles)],
            inhibited_muscles: [...new Set(longMuscles)],
            correction_priority: scoreDeductions > 30 ? "High" : "Moderate"
        };
    }
}

class AdvancedSleepEngine {
    analyze(data) {
        const totalTime = data.hours || 7.5;
        const consistency = data.consistency || 'variable';

        let cnsStatus = "Optimized";
        let recoveryScore = 100;
        const interventions = [];

        if (totalTime < 5) {
            cnsStatus = "Critically Depleted";
            recoveryScore -= 50;
            interventions.push("Extend Sleep Opportunity Window (+90min)");
        } else if (totalTime < 7) {
            cnsStatus = "Under-recovered";
            recoveryScore -= 20;
        }

        if (consistency === 'variable') {
            recoveryScore -= 10;
            interventions.push("Anchor Wake-Up Time");
        }

        return {
            score: recoveryScore,
            cns_status: cnsStatus,
            hygiene_protocol: interventions
        };
    }
}

class AdvancedCardioEngine {
    analyze(data) {
        const rhr = data.rhr || 70;
        const age = data.age || 30;
        const maxHr = 220 - age;
        const hrr = maxHr - rhr;

        const vo2Proxy = 15.3 * (maxHr / rhr);

        let score = 70;
        let category = "Average";
        if (vo2Proxy > 50) {
            category = "Superior (Athlete)";
            score = 95;
        }

        return {
            score: score,
            status: category,
            hr_training_zones: {
                "zone_2": `${Math.round(rhr + 0.6 * hrr)}-${Math.round(rhr + 0.7 * hrr)} bpm`,
                "zone_5": `${Math.round(rhr + 0.9 * hrr)}-${maxHr} bpm`
            }
        };
    }
}

class AdvancedStrengthEngine {
    analyze(data) {
        const score = data.score || 0; // Keeping it simple if no specific test data
        const plank = data.plank_sec || 45;

        const leaks = [];
        const coreLimit = Math.min(100, (plank / 90) * 100);

        if (coreLimit < 70) leaks.push("Midline Instability (Core)");

        return {
            score: Math.round(coreLimit),
            weak_link: leaks.length > 0 ? leaks[0] : "None",
            training_priority: leaks.length > 0 ? "Core Control" : "Hypertrophy"
        };
    }
}

class AdvancedNutritionEngine {
    analyze(data) {
        const waterL = data.water_liters || 1.5;
        const weightKg = data.weight_kg || 70;

        let score = 100;
        const targetWater = weightKg * 0.035;
        if (waterL / targetWater < 0.7) score -= 20;

        return {
            score: score,
            inflammation_risk: "Low"
        };
    }
}

class AdvancedHistoryEngine {
    analyze(data) {
        const episodes = data.prev_episodes || 0;
        const resilienceScore = 100 - (10 * episodes);
        const recurrenceRisk = 0.15 + (0.15 * episodes);

        return {
            score: Math.max(10, resilienceScore),
            recurrence_probability: `${Math.min(90, Math.round(recurrenceRisk * 100))}%`
        };
    }
}

class BiopsychosocialEngine {
    analyze(social, stress) {
        const stressLevel = stress.stress_level || 5;
        const fearAvoidance = stress.fear_movement || false;

        let bpsScore = 100;
        const barriers = [];

        if (stressLevel > 7) {
            bpsScore -= 20;
            barriers.push("HPA Axis Dysregulation (High Cortisol)");
        }

        if (fearAvoidance) {
            bpsScore -= 30;
            barriers.push("Kinesiophobia (Fear of Movement)");
        }

        return {
            score: bpsScore,
            allostatic_load: stressLevel,
            risk_factors: barriers
        };
    }
}

class ErgoEngine {
    analyze(data) {
        const sitting = parseFloat(data.sitting_hours || 4);
        const screenH = data.screen_level || 'eye';

        let rsiRisk = "Low";
        let score = 100;

        if (sitting > 6 && screenH === 'low') {
            rsiRisk = "High - Ergonomic Hazard";
            score -= 50;
        }

        return { rsi_risk: rsiRisk, score: score };
    }
}

class PhysiqueEngine {
    analyze(data) {
        const current = parseFloat(data.weight || 70);
        const goal = data.goal || 'maintenance';

        let futureW = current;
        if (goal === 'build') futureW = current * 1.05;
        if (goal === 'cut') futureW = current * 0.92;

        return {
            projected_weight: Math.round(futureW * 10) / 10,
            timeline_weeks: 24,
            score: 100
        };
    }
}

module.exports = {
    AdvancedPainEngine,
    AdvancedMobilityEngine,
    AdvancedPostureEngine,
    AdvancedSleepEngine,
    AdvancedCardioEngine,
    AdvancedStrengthEngine,
    AdvancedNutritionEngine,
    AdvancedHistoryEngine,
    BiopsychosocialEngine,
    ErgoEngine,
    PhysiqueEngine
};
