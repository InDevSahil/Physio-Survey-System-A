/**
 * Healing Timeline Calculator.
 * Biology Rule: Different tissues heal at different metabolic rates.
 */
class RecoveryTrajectoryEngine {
    predict(tissue, severity, modifiers) {
        // Base metabolic healing rates (Approximate clinical averages)
        let baseWeeks = 4;

        if (tissue.includes('bone')) baseWeeks = 8;
        if (tissue.includes('nerve')) baseWeeks = 12; // Nerves heal very slowly (1mm/day)
        if (tissue.includes('tendon')) baseWeeks = 12; // Tendons have poor blood supply
        if (tissue.includes('disc')) baseWeeks = 10; // Discs are avascular

        let factor = 1.0;

        // Modifiers that slow down healing
        if (modifiers.age > 40) factor += 0.2;
        if ((modifiers.sleep_avg || 7) < 6) factor += 0.3;

        const weeks = baseWeeks * factor;

        return {
            weeks_min: Math.round(weeks * 0.8 * 10) / 10,
            weeks_max: Math.round(weeks * 1.3 * 10) / 10
        };
    }
}

module.exports = RecoveryTrajectoryEngine;
