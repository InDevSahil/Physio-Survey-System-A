/**
 * The Safety Screen.
 * Checks for keywords that indicate NON-Musculoskeletal pathology types.
 */
class RedFlagEngine {
    constructor(kb) {
        this.kb = kb; // Expecting KnowledgeBase instance
    }

    scan(inputs) {
        const detectedFlags = [];
        let urgency = "Safe";

        // Combine all text inputs for scanning
        const symptomsText = inputs.symptoms_text || [];
        const historyText = inputs.history || [];
        const combinedText = [...symptomsText, ...historyText].join(" ").toLowerCase();

        // Scan for dangerous keywords
        for (const [condition, signs] of Object.entries(this.kb.redFlagCriteria)) {
            const found = signs.filter(sign => combinedText.includes(sign.toLowerCase().replace(/_/g, " ")));
            if (found.length > 0) {
                detectedFlags.push({ condition, signs: found });
                urgency = "Medical Evaluation Required";
            }
        }

        return {
            is_clear: detectedFlags.length === 0,
            flags: detectedFlags,
            urgency: urgency
        };
    }
}

module.exports = RedFlagEngine;
