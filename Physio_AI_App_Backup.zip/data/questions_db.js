/**
 * Comprehensive Medical Question Database
 * Categories: 
 * 1. Pain (30)
 * 2. Mobility (30)
 * 3. Posture (30)
 * 4. Sleep (30)
 * 5. Stress (30)
 * 6. Cardio (30)
 * 7. Strength (30)
 * 8. Ergo (30)
 * 9. Nutrition (30)
 */

const questionsDB = {
    // --- PAIN ---
    pain: [
        { id: 'p_curr', text: "Do you currently experience pain?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'p_loc', text: "Where is your primary pain located?", type: 'mcq', options: ['Low Back', 'Neck', 'Knee', 'Shoulder', 'Hip', 'Ankle'] },
        { id: 'p_dur', text: "How long have you had this pain?", type: 'mcq', options: ['< 2 weeks (Acute)', '2-12 weeks (Sub-acute)', '> 3 months (Chronic)'] },
        { id: 'p_int_rest', text: "Pain intensity at rest (0–10)?", type: 'slider', min: 0, max: 10 },
        { id: 'p_int_move', text: "Pain intensity with movement (0–10)?", type: 'slider', min: 0, max: 10 },
        { id: 'p_qual', text: "How would you describe the pain?", type: 'mcq', options: ['Sharp', 'Dull', 'Throbbing', 'Burning', 'Shooting'] },
        { id: 'p_rad', text: "Does pain radiate to other areas?", type: 'mcq', options: ['Yes', 'No'] },
        // Triggers
        { id: 'p_trig_sit', text: "Does sitting increase your pain?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'p_trig_stand', text: "Does standing increase your pain?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'p_trig_walk', text: "Does walking increase your pain?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'p_morn', text: "Does pain worsen in the morning?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'p_night', text: "Does pain worsen at night?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'p_numb', text: "Do you experience any numbness or tingling?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'p_weak', text: "Is there any associated weakness?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'p_imp_daily', text: "Does pain affect your daily activities?", type: 'mcq', options: ['Significantly', 'Moderately', 'Mildly', 'No'] }
    ],
    // --- SPECIALIST MODULES ---
    mobility: [
        { id: 'm_bend_fwd', text: "Do you have difficulty bending forward?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'm_bend_back', text: "Do you have difficulty bending backward?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'm_rot_neck', text: "Difficulty rotating neck?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'm_squat', text: "Difficulty squatting?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'm_stiff_morn', text: "Do you experience joint stiffness in the morning?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'm_stiff_dur', text: "Does stiffness last > 30 minutes?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'm_click', text: "Do your joints click or catch?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'm_lock', text: "Have you had joint locking episodes?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'm_fear', text: "Do you have fear of movement (Kinesiophobia)?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'm_fall', text: "Do you have a history of falls?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'm_rate', text: "Rate your overall mobility limitation (0–10):", type: 'slider', min: 0, max: 10 }
    ],
    posture: [
        { id: 'pos_slouch', text: "Do you sit with a slouched posture?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'pos_head', text: "Do you have forward head posture?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'pos_shoul', text: "Are your shoulders rounded forward?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'pos_arch', text: "Do you have an excessive lower-back arch?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'pos_flat', text: "Do you have a flat lower back?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'pos_sit_dur', text: "Do you sit for prolonged periods (> 6 hrs/day)?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'pos_screen', text: "Do you have prolonged screen usage?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'pos_check', text: "Do you frequently need to correct your posture?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'pos_fatigue', text: "Does maintaining good posture cause fatigue?", type: 'mcq', options: ['Yes', 'No'] }
    ],
    sleep: [
        { id: 's_dur', text: "What is your average sleep duration?", type: 'mcq', options: ['< 5 hrs', '5-7 hrs', '7-9 hrs', '> 9 hrs'] },
        { id: 's_fall', text: "Do you have difficulty falling asleep?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 's_stay', text: "Do you have difficulty staying asleep?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 's_refresh', text: "Do you wake up feeling unrefreshed?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 's_pain', text: "Does pain disturb your sleep at night?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 's_pos', text: "Does your sleep position cause pain?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 's_qual', text: "Rate your sleep quality (0–10):", type: 'slider', min: 0, max: 10 }
    ],
    stress: [
        { id: 'str_lvl', text: "Rate your daily stress level (0–10):", type: 'slider', min: 0, max: 10 },
        { id: 'str_work', text: "Do you experience high work/study stress?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'str_anx', text: "Do you have anxiety symptoms?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'str_relax', text: "Do you have difficulty relaxing?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'str_tension', text: "Do you feel muscle tension related to stress?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'str_pain', text: "Does stress worsen your pain?", type: 'mcq', options: ['Yes', 'No'] }
    ],
    cardio: [
        { id: 'c_sob', text: "Do you experience shortness of breath?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'c_stair', text: "Do you get breathless on stairs?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'c_exer', text: "Is your exercise tolerance low?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'c_swell', text: "Do you have swelling in your legs/ankles?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'c_sed', text: "Do you live a sedentary lifestyle?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'c_rate', text: "Rate your cardio fitness (0–10):", type: 'slider', min: 0, max: 10 }
    ],
    strength: [
        { id: 'st_gen', text: "Do you feel general abnormal weakness?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'st_grip', text: "Is your grip strength reduced?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'st_lift', text: "Do you have difficulty lifting objects?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'st_fatigue', text: "Do your muscles fatigue early?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'st_rate', text: "Rate your overall strength level (0–10):", type: 'slider', min: 0, max: 10 }
    ],
    ergo: [
        { id: 'e_desk', text: "How many hours do you spend at a desk per day?", type: 'mcq', options: ['0-2', '2-6', '6-10', '10+'] },
        { id: 'e_break', text: "Do you take frequent sitting breaks?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'e_chair', text: "Does your chair provide lumbar support?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'e_mon', text: "Is your monitor at eye level?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'e_rep', text: "Do you perform repetitive movements?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'e_pain', text: "Does your work correlate with your pain?", type: 'mcq', options: ['Yes', 'No'] }
    ],
    nutrition: [
        { id: 'n_water', text: "Is your water intake sufficient (>2L)?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'n_prot', text: "Is your protein intake adequate?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'n_junk', text: "Do you eat junk/processed food frequently?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'n_weight', text: "Have you had recent weight changes?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'n_eng', text: "Are your energy levels generally low?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'n_rate', text: "Rate your nutrition quality (0–10):", type: 'slider', min: 0, max: 10 }
    ],
    // --- HOLISTIC EXPANSION ---
    vision: [
        { id: 'vis_strain', text: "Do you experience eye strain or headaches after screen use?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'vis_blur', text: "Do you have blurred vision?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'vis_dry', text: "Do your eyes feel dry or gritty?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'vis_screen', text: "How many hours do you spend on screens daily?", type: 'mcq', options: ['<2', '2-6', '6-10', '10+'] }
    ],
    gastrointestinal: [
        { id: 'gi_bloat', text: "Do you experience frequent bloating or gas?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'gi_indig', text: "Do you suffer from heartburn or indigestion?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'gi_reg', text: "Is your bowel movement regular?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'gi_pain', text: "Do you have abdominal pain related to stress?", type: 'mcq', options: ['Yes', 'No'] }
    ],
    cardio_history: [
        { id: 'ch_bp', text: "Have you ever been told you have High Blood Pressure?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'ch_fam', text: "Is there a family history of heart disease?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'ch_palp', text: "Do you experience heart palpitations?", type: 'mcq', options: ['Yes', 'No'] }
    ],
    psych_behavioral: [
        { id: 'psy_anger', text: "Do you find yourself getting angry or irritable easily?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'psy_withdraw', text: "Have you been withdrawing from social interaction?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'psy_focus', text: "Do you have trouble staying focused on tasks?", type: 'mcq', options: ['Yes', 'No'] }
    ],
    habits: [
        { id: 'hab_smoke', text: "Do you smoke or vape?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'hab_alc', text: "Do you consume alcohol frequently?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'hab_sed', text: "Do you sit for more than 4 hours at a time without breaking?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'hab_sun', text: "Do you get daily sunlight exposure?", type: 'mcq', options: ['Yes', 'No'] }
    ],
    // --- MEDICAL ROS CATEGORIES ---
    constitutional: [
        { id: 'ros_fever', text: "Do you experience fevers or chills?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'ros_fatigue', text: "Do you have unexplained fatigue or weakness?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'ros_malaise', text: "Do you feel a general sense of uneasiness (malaise)?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'ros_weight', text: "Have you experienced unexplained weight loss?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'ros_sweat', text: "Do you experience night sweats?", type: 'mcq', options: ['Yes', 'No'] }
    ],
    neurological: [
        { id: 'neuro_numb', text: "Do you hav numbness or tingling?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'neuro_weak_foc', text: "Do you have specific limb weakness (e.g. drop foot, weak grip)?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'neuro_dizzy', text: "Do you experience dizziness or vertigo?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'neuro_tremor', text: "Do you have tremors or involuntary movements?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'neuro_fog', text: "Do you experience mental fog or confusion?", type: 'mcq', options: ['Yes', 'No'] }
    ],
    inflammatory: [
        { id: 'inflam_swell', text: "Do you have visible joint swelling?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'inflam_red', text: "Is there redness or warmth over any joint?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'inflam_stiff', text: "Does morning stiffness last more than 1 hour?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'inflam_rash', text: "Do you have any new skin rashes?", type: 'mcq', options: ['Yes', 'No'] }
    ],
    immune: [
        { id: 'imm_allergy', text: "Do you have any known allergies (Food, Drug, Environmental)?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'imm_sick', text: "Do you get sick/infections frequently?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'imm_react', text: "Do you have adverse reactions to medications?", type: 'mcq', options: ['Yes', 'No'] }
    ],
    psych_advanced: [
        { id: 'psy_dep', text: "Have you felt down, depressed, or hopeless recently?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'psy_anx', text: "Do you feel nervous, anxious, or on edge?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'psy_mood', text: "Do you experience rapid mood swings?", type: 'mcq', options: ['Yes', 'No'] },
        { id: 'psy_motiv', text: "Do you lack motivation for daily activities?", type: 'mcq', options: ['Yes', 'No'] }
    ],
};

module.exports = questionsDB;
