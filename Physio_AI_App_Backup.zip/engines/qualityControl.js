/**
 * Quality Control Engine
 * Detects "Gamer" behavior, inconsistent reporting, and speed clicking.
 */
class QualityControlEngine {
    constructor() {
        this.flags = [];
        this.warnings = [];
        this.responseTimes = [];
        this.lastResponseTime = Date.now();
    }

    /**
     * Analyze the latest interaction for quality issues.
     * @param {Object} input - { id, answer, timestamp (optional) }
     * @param {Array} history - Full history of answers
     */
    analyzeStep(input, history) {
        const now = Date.now();
        const timeDiff = now - this.lastResponseTime;
        this.lastResponseTime = now;
        this.responseTimes.push(timeDiff);

        // 1. SPEED CHECK
        // If answering faster than 1.5 seconds repeatedly, flag it.
        if (timeDiff < 1500) {
            this.warnings.push(`Speed Click: Answered '${input.id}' in ${timeDiff}ms`);
        }

        // 2. CONTRADICTION CHECKS
        this.checkContradictions(input, history);
    }

    checkContradictions(input, history) {
        const answer = input.answer.toString().toLowerCase();

        // Rule 1: Pain vs Severity
        if (input.id === 'p_int_rest' || input.id === 'pain_level') {
            const level = parseInt(answer);
            const noPain = history.find(h => h.id === 'p_curr' && h.answer === 'No');
            if (noPain && level > 2) {
                this.flags.push("Contradiction: Reported 'No Pain' initially but rated intensity > 2.");
            }
        }

        // Rule 2: Walk Distance vs Trigger
        if (input.id === 'p_trig_walk' && answer === 'yes') {
            const highMobility = history.find(h => h.id === 'm_rate' && parseInt(h.answer) > 8); // 8-10 means good mobility
            if (highMobility) {
                this.warnings.push("Inconsistency: Pain triggered by walking but rated Mobility very high.");
            }
        }

        // Rule 3: Age vs Work
        if (input.id === 'age') {
            const age = parseInt(answer);
            const workStress = history.find(h => h.id === 'str_work' && h.answer === 'Yes');
            if (age < 16 && workStress) {
                this.warnings.push("Unusual: Age < 16 reports high work stress.");
            }
        }
    }

    getReliabilityReport() {
        // Calculate Speed Score
        const fastClicks = this.responseTimes.filter(t => t < 1500).length;
        const totalAnswers = this.responseTimes.length;
        const speedRatio = totalAnswers > 0 ? fastClicks / totalAnswers : 0;

        let reliabilityScore = 100;

        if (speedRatio > 0.3) reliabilityScore -= 20; // 30% fast clicks
        if (speedRatio > 0.5) reliabilityScore -= 20; // 50% fast clicks
        reliabilityScore -= (this.flags.length * 15);
        reliabilityScore -= (this.warnings.length * 5);

        return {
            score: Math.max(0, reliabilityScore),
            flags: this.flags,
            warnings: this.warnings,
            isReliable: reliabilityScore > 70
        };
    }
}

module.exports = QualityControlEngine;
