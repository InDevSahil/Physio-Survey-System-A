const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const engine = require('./engine');

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '.'))); // Serve static files from root

// Load the Knee Module on startup (in a real app this might be dynamic)
engine.loadModule('knee');
// engine.loadModule('back'); // Placeholder for future

// API: Start a new session
app.post('/api/start', (req, res) => {
    // In a real DB, we'd create a session ID. 
    // Here we just return the 'root' question of the requested module.
    const moduleName = req.body.module || 'knee';
    const firstQuestion = engine.startSession(moduleName);
    res.json(firstQuestion);
});

// API: Answer a question and get the next one
app.post('/api/next', async (req, res) => {
    const { currentQuestionId, answerValue, history } = req.body;

    try {
        // Logic to determine next question
        const nextStep = await engine.getNextStep(currentQuestionId, answerValue, history);

        // If nextStep has a 'diagnosis' or 'summary' field, the survey is done.
        res.json(nextStep);
    } catch (err) {
        console.error("Error in /api/next:", err);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

// API: Force finish and get summary
app.post('/api/finish', (req, res) => {
    const { history } = req.body;
    // Generate summary based on current history
    const summary = engine.getSummaryNow(history);
    res.json(summary);
});

app.listen(port, () => {
    console.log(`Physio AI Server running at http://localhost:${port}`);
});
